# Backstory cross-model test kit

**Purpose:** check whether CAMS scores for ancient societies hold up when a different AI model does the scoring. A blind ensemble of five Claude scorers has already been run. This kit lets you run the same blind test on any other model (GPT, Gemini, Grok, DeepSeek, Kimi, Qwen, a local model) and compare.

Project: CAMS Through Deep Time ("Backstory"), Kari McKern / ComplexityWorkz, neuralnations.org. Kit prepared 2 October 2026.

## What is in the kit

| Folder | What it is | Show it to the model? |
| --- | --- | --- |
| `1_PASTE_INTO_OTHER_MODEL/` | The two blind scoring prompts | **Yes: these only** |
| `2_DO_NOT_SHOW_THE_MODEL/` | Hypotheses, run log, Claude's reference scores, analysis scripts | **No.** These reveal what each case is meant to test |
| `3_YOUR_RESULTS_GO_HERE/` | Empty folders for the other model's outputs; the report appears here | No |

Do not upload the whole zip to the model. Some models read every file in a zip, which would break the blind test.

## Step 1: Run Prompt A (twelve societies)

1. Open a **new, empty conversation** in the other model. No project files, no custom instructions, no memory of earlier chats if it can be switched off.
2. Copy the whole of `1_PASTE_INTO_OTHER_MODEL/PROMPT_A_twelve_societies.txt` and paste it in. Add nothing else.
3. The model should reply with CSV only: one header line and 96 rows.
4. Copy the reply into a plain text file and save it as `3_YOUR_RESULTS_GO_HERE/prompt_A/pass1.csv`.
5. Repeat in **four more new conversations**, saving `pass2.csv` to `pass5.csv`. Five passes give an ensemble; one pass still works but gives no spread.

If web search is offered, switch it off, so the model scores from its own knowledge as Claude did.

## Step 2: Run Prompt B (extra time windows)

Same as Step 1, using `PROMPT_B_extra_windows.txt`, in **new conversations** (not the ones used for Prompt A). Expect 80 rows. Save as `3_YOUR_RESULTS_GO_HERE/prompt_B/pass1.csv` … `pass5.csv`.

## Step 3: Check the outputs by eye

- First line exactly `Society,Year,Node,Coherence,Capacity,Stress,Abstraction`.
- Scores are whole numbers 1–10 or `NA`. `NA` is allowed and expected where evidence is thin.
- If the model wrapped the CSV in ``` marks or added a sentence, leave it: the script strips that.
- If it refused, explained instead of scoring, or stopped part-way, run that pass again in a new conversation and note it in your log.

## Step 4: Run the comparison

Needs Python 3 with pandas (`pip install pandas`). From this kit's top folder:

```
python 2_DO_NOT_SHOW_THE_MODEL/scripts/run_test.py
```

It cleans the files, builds the other model's ensemble, compares it with Claude's, runs all hypothesis tests, and writes `3_YOUR_RESULTS_GO_HERE/REPORT.md`.

## Step 5: Read the report

| Signal in REPORT.md | What it means |
| --- | --- |
| MAE under 1 and Spearman above 0.7 on each dimension | The instrument gives similar scores across models |
| Case-ranking Spearman above 0.8 | Both models agree which societies were strong or failing |
| NA disagreements mostly in Harappa, Minoan Crete, Xiongnu, Protogeometric Greece | The evidence gate is tracking real gaps in the record |
| A steady mean difference on one dimension | A calibration offset between models, not real disagreement |
| A hypothesis verdict that differs from Claude's | That result depends on the scorer; do not publish it as a finding |

Claude's own verdicts are in `2_DO_NOT_SHOW_THE_MODEL/claude_reference/`. In brief: H2 (collapse) and H5 (no ladder) held; H1 and H4 were scorer-dependent or failed; H3 held in Egypt only.

## Step 6: Record what you did

Note in your log: the model's name and version, the date, whether search was off, how many passes, and any retries. Add the report to the project's `results/` folder in the wintermute repo.

## Fairness notes

- Every model gets the same prompt, word for word. Do not reword it to suit a model.
- Do not tell the model it is being compared with Claude, or that it is one of several runs.
- If a model systematically scores one region differently (for example China, Egypt or Aboriginal Australia), that is a finding about the model's corpus, which is exactly what this test is meant to surface.
