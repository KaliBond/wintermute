# Backstory run log

Every run, decision and deviation is recorded here, newest first.

## 2026-10-02 — Run 3: extra time windows, five-scorer ensemble

**Design:** as run 2 — five Claude subagents in separate contexts, prompt `prompts/scorer_prompt_deeptime_v1.2-OPT_windows2.txt` only, no tools (all five confirmed zero tool use). Eight new windows plus B05 and B09 rescored as overlap anchors. Tests were fixed and hashed before scoring (entry below).
**Files:** `runs/ensemble_windows2_2026-10-02/` (scorer_1–5 verbatim, SHA256SUMS, block1, block2); `runs/combined_2026-10-02/` (all 20 windows, seam report, series checks under two overlap rules).

### Instrument checks
- Scorer agreement again tight: mean SD 0.21 (C), 0.22 (K), 0.32 (S), 0.41 (A); mean V range 1.64.
- **Seam** (run 2 vs run 3 ensemble means on B05 and B09, 60 cells): mean |diff| 0.24, max 1.0. Run 3 slightly lower on Coherence (−0.16) and Abstraction (−0.21). Small: the ensemble is stable across contexts.
- **NA ambiguity found:** Aegean Archive at −1175 was scored 1/1/9/1 by all five run-2 scorers ('collapsed') but NA by four of five run-3 scorers ('no evidence'). Protogeometric Archive is NA in all five. The gate does not distinguish *function absent* from *evidence absent*. Recommendation for DT-2: add an explicit rule — when the absence of a function is itself well evidenced (e.g. loss of literacy), score it low; reserve NA for unknown.

### Series (primary rule: run-2 values for overlap cases)
| Window | Year | Energy | Cognition | Helm–Lore C |
| --- | --- | --- | --- | --- |
| Egypt Old Kingdom | −2500 | 3.65 | 44.4 | 8.0 |
| Egypt late 5th dyn | −2400 | 2.60 | 37.8 | 6.6 |
| Egypt late 6th dyn | −2250 | 0.03 | 26.5 | 5.0 |
| Egypt FIP (breakdown) | −2150 | −2.75 | 15.5 | 3.6 |
| Egypt Middle Kingdom | −1900 | 3.33 | 45.0 | 7.0 |
| Mycenaean LH IIIA | −1350 | 2.12 | 31.6 | 5.5 |
| Mycenaean LH IIIB | −1250 | 0.70 | 32.5 | 5.6 |
| Aegean collapse (breakdown) | −1175 | −4.62 | 10.1 | 3.0 |
| Protogeometric | −1000 | −1.15 | 14.2 | 3.9 |
| Late Geometric | −750 | 0.65 | 26.8 | 5.4 |

### Pre-registered verdicts
| Hypothesis | Egypt | Aegean | Mesopotamia | Overall |
| --- | --- | --- | --- | --- |
| H2 recovery slower than fall | against (primary) / supports (alt overlap rule): fall and recovery rates nearly equal | supports strongly: fall −7.1/century, recovery +2.0; still below LH IIIB after 425 years | — | **Mixed; depends on case.** Robust in the Aegean only. |
| H3 Helm–Lore coherence falls first | supports: 8.0 → 6.6 → 5.0 while Energy stays positive | against: flat 5.5 → 5.6 before collapse | — | **Mixed.** |
| H4 relief edicts keep Hands' Stress low for longer | — | — | against: 7.0, 6.2, 7.2 vs comparator 5.93; 0 of 3 windows below | **Against.** |

### Reading (interpretation, not a test)
- Egypt shows the CAMS signature most cleanly: coherence between rulers and meaning-makers drains for two centuries while surplus is still positive, then Energy turns negative. If this holds in other cases it is a leading indicator. One case is not enough.
- The Aegean shows a different shape: no visible coherence lead, a sudden fall (sea-borne contagion, network failure) and a very slow recovery. Egypt, an inland river state, rebuilt its macro-order in under three centuries. That contrast is worth its own hypothesis (H6, below) — stated after seeing the data, so it must be tested on new cases.
- H4 as framed is probably confounded: debt-relief edicts are issued *because* labour is under debt stress, so high Hands' Stress in edict-issuing states is expected. A fair test needs states with and without edicts under comparable debt load. Recorded as a design flaw, not a rescue: H4 stands as **against**.

### New hypothesis (post hoc, flagged as such; not tested)
- **H6:** Recovery speed after breakdown depends on whether the setting forces re-coordination. Single river-valley states (Egypt, Mesopotamia, China) rebuild the macro-order faster than dispersed maritime networks (Aegean). Test cases: Mesopotamia after Ur III, Shang–Zhou transition, Late Bronze Age Levant, post-Harappan Indus.

## 2026-10-02 07:11 UTC — Pre-registration for run 3 (before any run-3 scoring)

- Series tests fixed in `scripts/hypothesis_check_series.py`, SHA-256 353aaeab264196584464d89618e8f46e4f9857d271617db57909ef0c71cf541f.
  - H2 recovery: per-century change in mean Energy and Cognition, fall leg vs first recovery leg; supports if both recover more slowly than they fell.
  - H3: Helm–Lore coherence (mean of Helm C and Lore C) must fall by at least 0.5 from the earliest to the last pre-collapse window, in each series.
  - H4: Mesopotamian Hands Stress (Ur III, Hammurabi, Ammisaduqa) below the mean of six non-collapse palace windows without attested debt relief, in all three windows.
- New windows (prompt `prompts/scorer_prompt_deeptime_v1.2-OPT_windows2.txt`, SHA-256 90b68399…): Ur III −2050; Egypt −2400, −2250, −1900; late Old Babylonian −1650; Mycenaean LH IIIA −1350; Greece −1000, −750.
- B05 (−2150) and B09 (−1175) are rescored as overlap anchors to measure seam (same scorer design, new context).
- Windows are listed out of chronological order within the prompt to reduce trajectory anchoring.

## 2026-10-02 — Run 2: five-scorer ensemble (Claude subagents)

**Design:** CAMNATIONSM5N paste-and-spawn, executed as five Claude subagents launched in parallel from the Cowork session. Each received only the DT-1 prompt (`prompts/scorer_prompt_deeptime_v1.2-OPT.txt`, SHA-256 64009fc6…) plus one identical wrapper line: answer from own knowledge, no tools, CSV only. No scorer saw the plan, hypotheses, evidence log or run 1. None was told it was one of five. All five reported zero tool use.
**Model:** same configured model as run 1 (`claude-opus-5-5`); so this is a same-model ensemble, not a cross-model test.
**Aggregation:** `scripts/aggregate_ensemble.py`, following the CAMNATIONSM5N spec (dimension-level NA, mean only if n_eff_d >= 3, sample SD, per-scorer V spread, bond_n >= 4). No batch overlap, so no SEAM line. All spec verification checks passed.

### Files
| File | Contents |
| --- | --- |
| `runs/ensemble_claude-subagents_2026-10-02/scorer_A.csv` … `scorer_E.csv` | Raw outputs, verbatim; hashes in `SHA256SUMS` |
| `…/block1_ensemble_mean.csv` | Ensemble mean C K S A, Node Value, Bond Strength |
| `…/block2_envelope.csv` | SD per dimension, V range, n_eff, NA_rate, bond_n |
| `…/node_metrics.csv`, `system_metrics.csv` | Cognition, Energy and case summaries from the means |
| `…/hypothesis_check.md` | H1–H5 on the ensemble |
| `results/comparison_pass1_vs_ensemble_2026-10-02.md` | Run 1 vs ensemble |

### Results
- **Scorer agreement is tight:** mean SD 0.21–0.30 per dimension; mean per-scorer Node Value range 1.57 (max 3.5: Xiongnu Craft, Mycenaean Flow, Aboriginal Shield). Same-model scorers share a corpus, so a tight envelope is expected and is *not* evidence of validity.
- **NA is honest and concentrated:** Longshan Archive and Minoan Shield NA in all five; Harappan Helm, Shield and Lore NA in four of five; Xiongnu Lore NA in four of five, Archive in three. These are the cases with no ruler, no deciphered script, or no own writing.
- **Run 1 vs ensemble:** MAE 0.33–0.48 per dimension, Spearman 0.93–0.95, case ranking Spearman 0.93. Run 1 was more extreme: collapses deeper (Aegean Stewards, Shield, Flow; FIP Hands, Stewards) and Old Kingdom higher. Abstraction +0.34 higher in the ensemble. Likely cause: run 1 was scored with the plan's narrative in context — the narrative-leakage risk the safeguards table names.

### Hypotheses: run 1 vs ensemble
| Hypothesis | Run 1 (in-session) | Ensemble (blind) | Status |
| --- | --- | --- | --- |
| H1a Stewards+Archive stronger in river states | supports (12.81 vs 11.45) | against (11.29 vs 11.32) | Scorer-dependent; not a finding |
| H1b Maritime Flow > Helm | Minoan NA, Māori +2.0 | Minoan +4.1, Māori +0.6, others −1.37 | Direction holds in both |
| H1c Xiongnu Shield–Flow | Shield 1st, Flow 3rd | Shield 1st, Flow 3rd | Holds in both |
| H2 Fall: Energy and Cognition drop together | 8/8 nodes both collapses | 8/8 nodes both collapses | Holds in both (fall leg only) |
| H3 Helm–Lore coherence leads collapse | not testable | not testable | Needs earlier windows |
| H4 Relief edicts lower Hands' Stress | against (7 vs 6.33) | supports (6.2 vs 6.73) | Scorer-dependent; not a finding |
| H5 No ladder | holds | holds | Holds in both |

### Still to do
- Cross-model test: run the same prompt in another model (see `TESTING.md`), and compare against `block1_ensemble_mean.csv`, which now replaces run 1 as the reference.
- Add pre-collapse windows (Egypt late 5th/6th dynasty; Mycenaean c.1350) and recovery windows (Middle Kingdom; Geometric Greece) to make H2 recovery and H3 testable.

## 2026-10-02 — Run 1: claude-opus-5-5, pass 1, all twelve cases

**Who/what:** scored by Claude (configured model ID `claude-opus-5-5`; the serving model may differ) in a Cowork session for Kari McKern.
**Rubric:** CAMS RAW SCORER v1.2-OPT with the deep-time adapter DT-1 (`prompts/scorer_prompt_deeptime_v1.2-OPT.txt`).
**Scope:** 12 cases x 8 nodes = 96 node cells, one anchor year per case.

### Files produced
| File | Contents |
| --- | --- |
| `runs/claude-opus-5-5_pass1/raw_scores.csv` | Raw C, K, S, A per node (96 rows, 9 NA nodes) |
| `runs/claude-opus-5-5_pass1/evidence_log.csv` | Gate decision per node: performance indicator, strain indicator, mechanism |
| `runs/claude-opus-5-5_pass1/node_metrics.csv` | + Cognition (A x C), Energy (K - S), Node Value, Bond Strength, bond_n |
| `runs/claude-opus-5-5_pass1/system_metrics.csv` | Case-level means and lowest-Energy node |
| `runs/claude-opus-5-5_pass1/hypothesis_check.md` | Preliminary H1-H5 reading |

### Steps
1. Anchor years fixed per case (see prompt table). Choices: Taosi phase for Longshan; Wu Ding era for Shang; Giza era for Old Kingdom; Hammurabi for Old Babylonian; LH IIIB for Mycenaean; 1700 CE for pre-contact Aboriginal Australia; 1500 CE for Māori; c.170 BCE for Xiongnu.
2. Each node passed through the three-box evidence gate; failures scored NA on all four dimensions and logged.
3. Scores entered; derived metrics computed with `scripts/backstory_calc.py`.
4. Hypotheses checked with `scripts/hypothesis_check.py`.
5. Blind prompt and comparison script prepared for cross-model testing (`TESTING.md`).

### Deviations from v1.2-OPT (adapter DT-1)
- Year = window anchor, not 31 December; t-1 baseline rule and the 2-point change constraint dropped (no time series within a case).
- Node examples reworded to ancient equivalents (priesthood, scribes, corvée); node boundaries kept functional.
- Oral record systems admitted as Archive evidence.
- Source posture extended to conquerors' accounts, later traditions and colonisers' ethnography.

### Known weaknesses of this run (read before citing)
- **Not blind.** The same model wrote the plan, the hypotheses and these scores in one session. H1-H5 were stated before scoring, but the operationalisations in `hypothesis_check.py` were written after. This is why the cross-model test matters.
- **Not independent.** One pass only; no scorer spread. Five independent passes (camnationsm5n) are still needed.
- **Prompt written after scoring.** The DT-1 prompt codifies the rules applied in this pass, but this pass was not produced by pasting that prompt into a fresh context. A fresh-context Claude pass should be added as the true like-for-like control.
- **Single anchors.** H2 recovery, H3 and the "for longer" part of H4 cannot be tested yet.
- **Evidence gate applied leniently** for 'limitation' as the strain indicator in stable cases (e.g. Harappan Craft: limited bronze use). Stricter reading would raise NA counts.

### Headline readings (pilot only)
- NA is concentrated where it should be: Harappan Helm/Shield/Lore/Stewards and Minoan Helm/Shield/Hands — the 'hidden Helm' societies.
- Both collapses (Egypt FIP, Aegean c.1175) show every node losing Energy and Cognition together.
- H4 (relief devices) reads against at the level of a single window: Old Babylonian Hands Stress 7 vs palace-state mean 6.33.
- H5 (no ladder) holds: non-state cases sit close to stable state cases on Energy and Cognition.
