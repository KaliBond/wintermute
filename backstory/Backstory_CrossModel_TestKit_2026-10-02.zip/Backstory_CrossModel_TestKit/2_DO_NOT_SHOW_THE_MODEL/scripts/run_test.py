"""One-step cross-model test. Run from the kit's top folder:
    python 2_DO_NOT_SHOW_THE_MODEL/scripts/run_test.py
Reads every .csv in 3_YOUR_RESULTS_GO_HERE/prompt_A and prompt_B, aggregates them,
compares against the Claude reference, runs the hypothesis checks, and writes
3_YOUR_RESULTS_GO_HERE/REPORT.md. Needs Python 3 and pandas (pip install pandas).
"""
import glob, os, subprocess, sys
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
TOP = os.path.dirname(os.path.dirname(HERE))
RES = os.path.join(TOP, "3_YOUR_RESULTS_GO_HERE")
REF = os.path.join(TOP, "2_DO_NOT_SHOW_THE_MODEL", "claude_reference")
OUT = os.path.join(RES, "output"); os.makedirs(OUT, exist_ok=True)
py = sys.executable
run = lambda *a: subprocess.run([py, *a], check=True, capture_output=True, text=True).stdout
D = ["Coherence","Capacity","Stress","Abstraction"]
report = ["# Cross-model test report\n"]

def clean(f):
    """Strip markdown fences or stray text a model may add around the CSV."""
    lines = [l.strip() for l in open(f, encoding="utf-8").read().splitlines()]
    start = next(i for i, l in enumerate(lines) if l.startswith("Society,Year,Node"))
    keep = [lines[start]] + [l for l in lines[start+1:] if l.count(",") == 6 and not l.startswith("Society,")]
    out = os.path.join(OUT, "clean_" + os.path.basename(os.path.dirname(f)) + "_" + os.path.basename(f))
    open(out, "w").write("\n".join(keep) + "\n")
    return out, len(keep) - 1

means = {}
for p, expect in [("prompt_A", 96), ("prompt_B", 80)]:
    files = sorted(glob.glob(os.path.join(RES, p, "*.csv")))
    if not files:
        report.append(f"## {p}: no files found, skipped\n"); continue
    cleaned = []
    for f in files:
        c, n = clean(f); cleaned.append(c)
        report.append(f"- {p}/{os.path.basename(f)}: {n} rows" + ("" if n == expect else f"  **WARNING: expected {expect}**"))
    od = os.path.join(OUT, p)
    if len(cleaned) >= 3:
        run(os.path.join(HERE, "aggregate_ensemble.py"), od, *cleaned)
        mean = os.path.join(od, "block1_ensemble_mean.csv")
        env = pd.read_csv(os.path.join(od, "block2_envelope.csv"), na_values=["NA"], keep_default_na=False)
        report.append(f"\n{p}: {len(cleaned)} passes aggregated. Mean scorer SD C {env.C_sd.mean():.2f} K {env.K_sd.mean():.2f} S {env.S_sd.mean():.2f} A {env.A_sd.mean():.2f}\n")
    else:
        mean = cleaned[0]
        report.append(f"\n{p}: fewer than 3 passes, using the first file alone (no ensemble).\n")
    means[p] = mean
    letter = p[-1]
    cmp_md = os.path.join(OUT, f"comparison_{p}.md")
    run(os.path.join(HERE, "compare_models.py"), os.path.join(REF, f"prompt{letter}_claude_ensemble_mean.csv"), mean, "--out", cmp_md)
    report.append(open(cmp_md).read().replace("# Model comparison", f"## {p}: other model vs Claude ensemble"))

if "prompt_A" in means:
    run(os.path.join(HERE, "backstory_calc.py"), means["prompt_A"], os.path.join(OUT, "A_calc"))
    run(os.path.join(HERE, "hypothesis_check.py"), os.path.join(OUT, "A_calc", "node_metrics.csv"), os.path.join(OUT, "hypotheses_H1_H5.md"))
    report.append(open(os.path.join(OUT, "hypotheses_H1_H5.md")).read().replace("# Preliminary hypothesis check", "## Other model: H1-H5"))
if len(means) == 2:
    a = pd.read_csv(means["prompt_A"], na_values=["NA"], keep_default_na=False)
    b = pd.read_csv(means["prompt_B"], na_values=["NA"], keep_default_na=False)
    ov = ["B05_FirstIntermediate_Egypt", "B09_LBA_Collapse_Aegean"]
    cols = ["Society","Year","Node"] + D
    allw = pd.concat([a[cols], b[~b.Society.isin(ov)][cols]])
    f = os.path.join(OUT, "all_windows_means.csv"); allw.to_csv(f, index=False, na_rep="NA")
    run(os.path.join(HERE, "backstory_calc.py"), f, os.path.join(OUT, "series_calc"))
    run(os.path.join(HERE, "hypothesis_check_series.py"), os.path.join(OUT, "series_calc", "node_metrics.csv"), os.path.join(OUT, "series_check.md"))
    report.append(open(os.path.join(OUT, "series_check.md")).read().replace("# Series hypothesis check", "## Other model: series tests H2-H4"))
report.append("\n---\nCompare the hypothesis verdicts above with `2_DO_NOT_SHOW_THE_MODEL/claude_reference/claude_hypothesis_check.md` and `claude_series_check.md`. A verdict that flips between models is scorer-dependent and should not be published as a finding.\n")
open(os.path.join(RES, "REPORT.md"), "w").write("\n".join(report))
print("Done. Open 3_YOUR_RESULTS_GO_HERE/REPORT.md")
