#!/usr/bin/env python3
"""Builds the public web page predictions-2027-2028.html (drops into the neuralnations.org site: uses style.css, site-chrome.js, nav.js)."""
import os, html as H
import numpy as np, pandas as pd
import build_documents as D
HERE=os.path.dirname(os.path.abspath(__file__)); PKG=os.path.join(HERE,'..')
T=D.T; SY=D.SY
e=lambda s:H.escape(str(s),quote=True)
pc=D.pc
def fan():
    soc_order=['USA','China','Australia']; W=860; xmin,xmax=-2.0,16.0; L=150; R=24; pw=W-L-R
    X=lambda v:L+(v-xmin)/(xmax-xmin)*pw
    out=[]; y=0; H_=0
    for soc in soc_order:
        S=D.SURFS[soc]; ph=34+len(S)*34+28; H_+=ph
    svg=[f'<svg viewBox="0 0 {W} {H_+30}" role="img" aria-labelledby="fan-t fan-d" class="fan"><title id="fan-t">Projected mean node value (V̄) in 2028 by dataset</title><desc id="fan-d">For each society and dataset, the 2026 or 2025 base value (diamond), the 2028 median (dot) and the 80% interval (bar). Dashed lines mark V̄ = 4 and V̄ = 10.</desc>']
    y0=0
    for soc in soc_order:
        S=D.SURFS[soc]; ph=34+len(S)*34+28
        svg.append(f'<text x="0" y="{y0+18}" class="ft">{e(D.NAME[soc])}</text>')
        top=y0+30; bot=top+len(S)*34
        for v in (0,4,10):
            svg.append(f'<line x1="{X(v):.1f}" y1="{top-4}" x2="{X(v):.1f}" y2="{bot}" class="{"fz" if v==0 else "fd"}"/>')
        for i,s in enumerate(S):
            r=SY[(SY.Society==soc)&(SY.Surface==s)&(SY.Year==2028)].iloc[0]; cy=top+i*34+17
            svg.append(f'<text x="{L-10}" y="{cy+4}" text-anchor="end" class="fl">{e(s)}</text>')
            svg.append(f'<line x1="{X(r.Vbar_p10):.1f}" y1="{cy}" x2="{X(r.Vbar_p90):.1f}" y2="{cy}" class="fb"/>')
            svg.append(f'<circle cx="{X(r.Vbar_med):.1f}" cy="{cy}" r="5" class="fm"><title>{e(soc)} {e(s)} 2028 median {r.Vbar_med:.1f}, 80% interval {r.Vbar_p10:.1f} to {r.Vbar_p90:.1f}</title></circle>')
            svg.append(f'<path d="M{X(r.Vbar_base):.1f} {cy-6} l6 6 l-6 6 l-6 -6 z" class="fs"><title>Base {r.Vbar_base:.1f} ({int(r.BaseYear)})</title></path>')
        ax=bot+14
        for v in range(-2,17,2): svg.append(f'<text x="{X(v):.1f}" y="{ax}" text-anchor="middle" class="fa">{v}</text>')
        y0+=ph
    svg.append(f'<text x="{L}" y="{H_+24}" class="fa">V̄ = 0 · 4 · 10 are thresholds in the regime rules; regimes also depend on V_min and B̄.</text></svg>')
    return ''.join(svg)
def claims_html(soc):
    S=D.SURFS[soc]; rows=['<div class="tw"><table class="claims"><thead><tr><th>ID</th><th>Prediction</th><th>Our probability</th><th>Across datasets</th><th>Type</th></tr></thead><tbody>']
    for _,r in T[T.Society==soc].iterrows():
        rng=' · '.join(f'{s} {pc(r[s])}' for s in S) if r.Tier!='C' else 'conditional claim'
        badge={'A':'<span class="tier a">A</span>','B':'<span class="tier b">B</span>','C':'<span class="tier c">C</span>'}[r.Tier]
        note={'judgement':' <small>(judgement)</small>','base rate':' <small>(base rate)</small>'}.get(r.Basis,'')
        rows.append(f'<tr><td class="id">{e(r.ID)}</td><td>{e(r.Text)}<div class="fals">Fails if: {e(r.Falsified)}</div></td><td class="p">{pc(r.Stated)}{note}</td><td class="rg">{e(rng)}</td><td>{badge}</td></tr>')
    rows.append('</tbody></table></div>')
    if soc=='USA': rows.append('<p class="legend">“Our probability” is the primary-dataset figure capped to the range 5–95% as a model-risk haircut, so a dataset showing 100% is stated as 95%. Type A: the probability varies by 25 points or less across datasets. Type B: it varies by more. Type C: conditional.</p>')
    return ''.join(rows)
def basetable():
    rows=['<div class="tw"><table class="claims"><thead><tr><th>Society</th><th>Dataset</th><th>Latest scored year</th><th>Mean V̄</th><th>Regime</th><th>2028 median (80% interval)</th></tr></thead><tbody>']
    for soc in ['USA','China','Australia']:
        for s in D.SURFS[soc]:
            r=SY[(SY.Society==soc)&(SY.Surface==s)&(SY.Year==2028)].iloc[0]
            rows.append(f'<tr><td>{e(D.NAME[soc])}</td><td>{e(s)}{" · primary" if s=="UNIFIED" else ""}</td><td>{int(r.BaseYear)}</td><td>{r.Vbar_base:.2f}</td><td>{e(r.Regime_base)}</td><td>{D.mn(r.Vbar_med)} ({D.mn(r.Vbar_p10)} to {D.mn(r.Vbar_p90)})</td></tr>')
    rows.append('</tbody></table></div>'); return ''.join(rows)
def src_links(soc): return ', '.join(f'<a href="{e(u)}" rel="noopener">{e(n)}</a>' for n,u in D.SRC[soc])
def hl(soc): return D.HEADLINE[soc]
nA=int((T.Tier=='A').sum()); nB=int((T.Tier=='B').sum())
def card(soc,big,small): return f'<div class="fact"><strong>{big}</strong><span><b>{e(D.NAME[soc])}.</b> {small}</span></div>'
U=lambda cid:pc(T[T.ID==cid].Stated.iloc[0])
page=f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Predictions 2027–2028: the United States, China and Australia — Neural Nations</title>
<meta name="description" content="Prospective, falsifiable CAMS/JUNO predictions for the United States, China and Australia in 2027 and 2028, lodged before the outcomes are scored. {len(T)} claims, each with a stated probability and a rule for how it will be judged.">
<link rel="canonical" href="https://neuralnations.org/predictions-2027-2028">
<link rel="stylesheet" href="style.css">
<style>
:root{{--page:#ffffff;--ink:#1c2333;--muted:#5d6577;--accent:#2F6F7D;--accent-soft:#e8f1f3;--amber:#9a6a12;--amber-soft:#f6ecd4;--line:#E0E0E0}}
*{{box-sizing:border-box}} body{{background:var(--page);color:var(--ink)}}
.report{{max-width:920px;margin:0 auto;padding:0 24px 80px;font-family:Georgia,'Times New Roman',serif;line-height:1.68;font-size:17px}}
header.masthead{{border-bottom:3px double var(--line);padding:42px 0 24px;margin-bottom:22px}}
.brand{{font-family:-apple-system,'Segoe UI',sans-serif;font-size:13px;letter-spacing:.24em;text-transform:uppercase;color:var(--accent);font-weight:700}} .brand span{{color:var(--muted)}}
.report h1{{font-size:38px;line-height:1.15;margin:14px 0 10px}} .subtitle{{font-size:19px;color:var(--muted);font-style:italic;margin:0 0 16px}}
.meta{{font-family:-apple-system,'Segoe UI',sans-serif;font-size:13px;color:var(--muted)}} .meta b{{color:var(--ink)}}
.toc{{display:flex;flex-wrap:wrap;gap:6px 4px;font-family:-apple-system,'Segoe UI',sans-serif;font-size:13px;margin:0 0 10px}}
.toc a{{color:var(--accent);text-decoration:none;padding:3px 9px;border:1px solid var(--line);border-radius:14px}} .toc a:hover{{background:var(--accent-soft)}}
.kicker{{font-family:-apple-system,'Segoe UI',sans-serif;font-size:12px;letter-spacing:.14em;text-transform:uppercase;color:var(--accent);font-weight:700;margin-top:50px;padding-top:20px;border-top:1px solid var(--line)}}
.report h2{{font-size:25px;margin:6px 0 14px}} .report h3{{font-size:19px;margin:26px 0 8px}} .report p{{margin:0 0 16px}}
.factgrid{{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin:24px 0}}
.fact{{border:1px solid var(--line);border-top:4px solid var(--accent);border-radius:6px;padding:14px 16px;font-family:-apple-system,'Segoe UI',sans-serif}}
.fact strong{{display:block;font-size:26px;color:var(--accent);line-height:1.2}} .fact span{{display:block;font-size:13.5px;color:var(--muted);margin-top:4px;line-height:1.45}}
.pull{{border-left:4px solid var(--accent);padding:4px 0 4px 20px;margin:26px 0;font-size:21px;font-style:italic;line-height:1.5}}
.callout{{border:1px solid var(--line);border-left:5px solid var(--amber);border-radius:6px;background:var(--amber-soft);padding:16px 20px;margin:24px 0;font-size:16px}}
.summary{{border:1px solid var(--line);border-left:5px solid var(--accent);border-radius:6px;padding:18px 24px;margin:22px 0}}
.tw{{overflow-x:auto;margin:14px 0 22px}}
table.claims{{border-collapse:collapse;width:100%;font-family:-apple-system,'Segoe UI',sans-serif;font-size:13.5px;line-height:1.45}}
table.claims th{{text-align:left;background:var(--accent-soft);color:var(--ink);padding:8px 10px;border-bottom:2px solid var(--line);font-size:12.5px}}
table.claims td{{padding:9px 10px;border-bottom:1px solid var(--line);vertical-align:top}}
td.id{{font-weight:700;color:var(--accent);white-space:nowrap}} td.p{{font-size:17px;font-weight:700;white-space:nowrap}} td.p small{{font-size:11px;font-weight:400;color:var(--muted)}} td.rg{{color:var(--muted);font-size:12.5px}}
.fals{{color:var(--muted);font-size:12.5px;margin-top:3px}}
.tier{{display:inline-block;min-width:22px;text-align:center;border-radius:11px;padding:1px 8px;font-weight:700;font-size:12px;color:#fff}} .tier.a{{background:var(--accent)}} .tier.b{{background:var(--amber)}} .tier.c{{background:#6b7280}}
svg.fan{{width:100%;height:auto;font-family:-apple-system,'Segoe UI',sans-serif}} svg.fan .ft{{font-size:14px;font-weight:700;fill:var(--ink)}} svg.fan .fl{{font-size:12px;fill:var(--ink)}} svg.fan .fa{{font-size:11px;fill:var(--muted)}}
svg.fan .fb{{stroke:var(--accent);stroke-width:9;stroke-linecap:round;opacity:.35}} svg.fan .fm{{fill:var(--accent)}} svg.fan .fs{{fill:#fff;stroke:var(--ink);stroke-width:1.4}} svg.fan .fd{{stroke:var(--muted);stroke-dasharray:4 4}} svg.fan .fz{{stroke:#b91c1c;stroke-dasharray:2 3}}
.legend{{font-family:-apple-system,'Segoe UI',sans-serif;font-size:12.5px;color:var(--muted);margin:-6px 0 18px}}
.gloss{{display:grid;grid-template-columns:repeat(2,1fr);gap:4px 24px;font-family:-apple-system,'Segoe UI',sans-serif;font-size:14px;margin:12px 0 20px}}
.endnote{{border-top:3px double var(--line);margin-top:48px;padding-top:18px;font-size:14.5px;color:var(--muted)}} .report ul{{padding-left:22px}} .report li{{margin-bottom:6px}}
@media(max-width:720px){{.factgrid{{grid-template-columns:1fr}} .gloss{{grid-template-columns:1fr}} .report h1{{font-size:30px}}}}
</style>
</head>
<body>
<nav class="navbar" id="site-nav"></nav>
<main class="report">
<header class="masthead">
  <div class="brand">Neural Nations <span>· CAMS prospective predictions</span></div>
  <h1>Predictions for 2027 and 2028</h1>
  <p class="subtitle">The United States, China and Australia: what the CAMS instrument expects to read, lodged before the answers exist</p>
  <div class="meta"><b>Kari McKern</b> · ComplexityWorkz · {D.DATE} · Version {D.VERSION} · JUNO v1.2-Final · {len(T)} claims · Archive DOI: <span id="doi">to be inserted after deposit</span></div>
</header>
<nav class="toc" aria-label="Sections"><a href="#what">What this is</a><a href="#headline">Headline</a><a href="#chart">The picture</a><a href="#usa">United States</a><a href="#china">China</a><a href="#australia">Australia</a><a href="#honest">Where we are unsure</a><a href="#judged">How it will be judged</a><a href="#context">Context</a><a href="#earlier">Earlier lodgements</a><a href="#files">Files</a></nav>

<section id="what"><div class="kicker">What this is</div><h2>A forecast the instrument can fail</h2>
<p>CAMS reads a society as eight cooperating functions and scores each on coherence, capacity, stress and abstraction. JUNO turns those scores into a handful of summary quantities and a regime label. These predictions say what those quantities and labels will look like for the United States, China and Australia in 2027 and 2028, with a probability on each claim and a rule fixed in advance for how it will be scored.</p>
<p>It is a thermometer reading projected forward, not a crystal ball. It makes no claim about events, causes or the intentions of any government, and it takes no political side. The scores are model-generated readings of the documentary record, and JUNO v1.2 has not been externally validated. Scoring these predictions is part of the test that would begin to change that.</p>
<div class="callout"><b>The main thing to know.</b> Each society has several scored datasets, and they disagree by more than the instrument’s stated margin of error. We therefore report every claim on every dataset and label each claim by how stable it is across them. Of {len(T)} claims, {nA} are <b>Tier A</b> (about the same on every dataset), {nB} are <b>Tier B</b> (they depend on which dataset is used) and one is conditional.</div>
<h3>The eight functions</h3>
<div class="gloss">{''.join(f'<div><b>{e(a)}</b> — {e(b)}</div>' for a,b in D.GLOSS)}</div>
</section>

<section id="headline"><div class="kicker">Headline</div><h2>What we expect, in plain terms</h2>
<div class="factgrid">
{card('USA',U('US-1'),'No return to a “Strained” or healthier reading in 2027 or 2028 (US-1). Shield stays among the two strongest functions ('+U('US-2')+', US-2).')}
{card('China',U('CN-4')+' / '+U('CN-5'),'Hands and Stewards stay among the three weakest functions on every dataset (CN-4, CN-5). Whether China reads “Stable Adaptive” depends on the dataset (CN-2).')}
{card('Australia',U('AU-4'),'Archive stays among the three strongest functions (AU-4). The regime label sits near a boundary, so label claims are dataset-dependent.')}
</div>
<p class="pull">On the overall score, we make no call on whether it rises or falls. The model finds about a coin flip in every society, and the register says so.</p></section>

<section id="chart"><div class="kicker">The picture</div><h2>Where each dataset puts 2028</h2>
{fan()}
<p class="legend">Diamond: latest scored value. Dot: 2028 median. Bar: 80% interval. Dashed lines at 4 and 10 are V̄ thresholds in the regime rules; the dotted red line at 0 marks the Freeze/Collapse side. Datasets for the same society differ in level, not just in noise.</p></section>

<section id="usa"><div class="kicker">I · United States</div><h2>Capacity intact, coordination impaired</h2>
<p>{e(hl('USA'))}</p>
{claims_html('USA')}
<p><b>Where the four datasets disagree.</b> {e(D.DISAGREE['USA'])}</p></section>

<section id="china"><div class="kicker">II · China</div><h2>Agreement on shape, disagreement on level</h2>
<p>{e(hl('China'))}</p>
{claims_html('China')}
<p><b>Where the datasets disagree.</b> {e(D.DISAGREE['China'])}</p>
<div class="callout"><b>A note on evidence.</b> Scorers read documentary evidence. Records about different societies differ in how open, abundant and self-critical they are, and shared model bias could push scores up or down. This register does not assume it runs in either direction. It is the reason China’s regime-level claims are labelled dataset-dependent and the evidence-gated NA rates are flagged as the most useful next check.</div></section>

<section id="australia"><div class="kicker">III · Australia</div><h2>Balanced on a boundary</h2>
<p>{e(hl('Australia'))}</p>
{claims_html('Australia')}
<p><b>Where the datasets disagree.</b> {e(D.DISAGREE['Australia'])}</p></section>

<section id="honest"><div class="kicker">Where we are unsure</div><h2>Base states by dataset</h2>
<p>The table is the heart of the uncertainty. Reading across any society’s rows, the starting point is not agreed, which is why a single regime verdict would overstate what the instrument knows.</p>
{basetable()}
<h3>Limits</h3><ul>{''.join(f'<li>{e(x)}</li>' for x in D.LIMITS)}</ul></section>

<section id="judged"><div class="kicker">How it will be judged</div><h2>Rules fixed in advance</h2>
<ul>
<li><b>When:</b> each year’s claims are scored after that year closes, from the first complete five-scorer ensemble scoring, with the dataset name and commit recorded.</li>
<li><b>Primary dataset:</b> the unified dataset named by the frozen register. If it has no 2027 or 2028 row, the claim is scored on whatever exists and marked as such.</li>
<li><b>Tier A</b> claims get a hit or miss on the primary dataset and are also reported on every other. <b>Tier B</b> claims get a single verdict only if every available dataset agrees; otherwise they are recorded as dataset-dependent, which counts as neither.</li>
<li><b>Brier scores</b> are reported for all claims and for Tier A separately. Claims are correlated, so they are not independent trials.</li>
<li><b>No edits.</b> Thresholds, wording and probabilities are fixed at deposit. Corrections go in a dated erratum.</li></ul></section>

<section id="context"><div class="kicker">Context</div><h2>What is happening, and is not modelled</h2>
<p><b>United States.</b> {e(D.CONTEXT['USA'])} ({src_links('USA')})</p>
<p><b>China.</b> {e(D.CONTEXT['China'])} ({src_links('China')})</p>
<p><b>Australia.</b> {e(D.CONTEXT['Australia'])} ({src_links('Australia')})</p>
<p>None of this enters the simulation. If an event inside the window moves the scores, that is information about the world, not a reason to reinterpret the claims.</p></section>

<section id="earlier"><div class="kicker">Earlier lodgements</div><h2>How this fits with what is already on the record</h2>
<p>This register does not replace the <a href="predictions.html">six-nation predictions of 12 July 2026</a> or the twelve claims locked on 10 June 2026 and frozen on 28 August 2026. Those stay in force and are scored separately. The 12 July memo was issued under a v1.0-labelled classifier table; this register and the frozen register’s scoring protocol use JUNO v1.2-Final. Where a claim here overlaps an earlier one (US-4, CN-2, CN-6, AU-2, AU-3), it is flagged and the earlier wording governs the earlier claim.</p></section>

<section id="files"><div class="kicker">Files</div><h2>Archive, data and code</h2>
<p>The full register, every probability by dataset, the input data and the code that regenerates every number are deposited together. Archive DOI: <b>to be inserted after deposit</b>. Upstream repository: <a href="https://github.com/KaliBond/wintermute" rel="noopener">KaliBond/wintermute</a>.</p>
<p>Suggested citation: McKern, K. (2026). <i>CAMS/JUNO v1.2 prospective predictions 2027–2028: United States, China and Australia</i> (Version {D.VERSION}). Neural Nations / ComplexityWorkz. Text and data CC BY 4.0; code MIT.</p></section>

<div class="endnote"><p>This is a research instrument offered for peer review. It is not a movement, a political position, advice or a validated causal model.</p></div>
</main>
<footer class="footer"><nav style="margin-bottom:10px;display:flex;gap:20px;justify-content:center;flex-wrap:wrap;"><a href="index.html" style="color:#1f77b4;text-decoration:none;font-size:0.9em;font-weight:600;">Home</a><a href="explore.html" style="color:#1f77b4;text-decoration:none;font-size:0.9em;font-weight:600;">Explore</a><a href="results.html" style="color:#1f77b4;text-decoration:none;font-size:0.9em;font-weight:600;">Results</a></nav><p>&copy; 2026 Kari McKern — Neural Nations CAMS Research. Built as open science — contributions &amp; forks welcome at <a href="https://github.com/KaliBond/wintermute" target="_blank">KaliBond/wintermute</a>.</p></footer>
<script src="site-chrome.js"></script><script src="nav.js"></script>
</body>
</html>
'''
open(os.path.join(PKG,'predictions-2027-2028.html'),'w',encoding='utf-8').write(page); print('web page',len(page))
