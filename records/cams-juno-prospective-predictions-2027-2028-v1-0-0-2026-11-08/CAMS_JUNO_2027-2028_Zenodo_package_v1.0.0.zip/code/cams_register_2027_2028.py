#!/usr/bin/env python3
"""
CAMS / JUNO v1.2-Final  -  Prospective register 2027-2028 (USA, China, Australia)
Reproduces every probability in the register from the input extracts in ../data using fixed seeds.
Run:  python3 cams_register_2027_2028.py     (writes ../results/*.csv)
Method (fixed at lodging):
  * 32-dimensional (8 nodes x C,K,S,A) annual random walk from each surface's last observed state, clipped to [1,10].
  * Noise covariance from anchor-to-anchor changes (repeated rows removed, scaled by sqrt(gap)), shrunk toward the diagonal
    (30% if >=50 anchors, else 60%) plus 1e-4*I.
  * Three scenarios, equal weight, 3000 paths each: PERSIST, DRIFT (mean annual change of years>=2015), REVERT
    (0.5*drift + 0.15*(mean - x); mean = 1980+ mean, or full-sample mean if the series starts after 1980).
  * Classifier: JUNO v1.2-Final (sign-preserving s, 6 dp rounding, v1.2 precedence).
  * Stated probability = primary-surface (UNIFIED) probability capped to [5%,95%], except where flagged (judgement / base rate).
"""
import os, sys, json, hashlib, platform
import numpy as np, pandas as pd
HERE=os.path.dirname(os.path.abspath(__file__)); DATA=os.path.join(HERE,'..','data'); OUT=os.path.join(HERE,'..','results'); os.makedirs(OUT,exist_ok=True)
N=['Helm','Shield','Lore','Archive','Stewards','Craft','Flow','Hands']; ix=N.index
SEED=2026; NPATH=3000; SEV=['Freeze/Collapse','Systemic Crisis','Phantom Type II','Local Node Failure']

def classify(C,K,S,A):
    V=C+K-S+.5*A; q=(.6*C+.4*A)/10
    W=np.sqrt(np.outer(q,q))*2.0**(-(np.add.outer(S,S))/10); np.fill_diagonal(W,0)
    Bb=round(W.sum()/56,6); Vb=round(V.mean(),6); Vm=round(V.min(),6)
    M=K-S; s=(A*C/100)*np.sign(M)*np.maximum(np.abs(M),.1); sm=round(s.min(),6)
    if Vb<0 and Vm<-3 and Bb<.15: r='Freeze/Collapse'
    elif Vb<6 and Vm<0 and Bb<.20: r='Systemic Crisis'
    elif sm<-.65: r='Phantom Type II'
    elif Vm<4.0: r='Local Node Failure'
    elif Vb>10 and Vm>5 and Bb>.28 and sm>-.25: r='Stable Adaptive'
    elif Vb>=4: r='Strained'
    else: r='Unclassified'
    return dict(V=V,Vbar=Vb,Vmin=Vm,Bbar=Bb,smin=sm,regime=r)
state=lambda x:classify(x[:8],x[8:16],x[16:24],x[24:32])

def load(fn):
    d=pd.read_csv(os.path.join(DATA,fn)); d=d[d.Node.isin(N)]
    ok=d.groupby('Year').Node.nunique(); d=d[d.Year.isin(ok[ok==8].index)]; out={}
    for y,g in d.groupby('Year'):
        g=g.set_index('Node').loc[N]; out[int(y)]=np.hstack([g[c].values.astype(float) for c in ['Coherence','Capacity','Stress','Abstraction']])
    return pd.DataFrame(out).T.sort_index()
SURF={'USA':{'UNIFIED':'USA_UNIFIED.csv','MARKER':'USA_MARKER.csv','MFIN':'USA_MFIN.csv','M5N':'USA_M5N.csv'},
      'China':{'UNIFIED':'China_UNIFIED.csv','CAMS1900':'China_CAMS1900.csv','M5N':'China_M5N.csv'},
      'Australia':{'UNIFIED':'Australia_UNIFIED.csv','CAM5_1996':'Australia_CAM5_1996.csv','M5N':'Australia_M5N.csv'}}

def anchor_diffs(X):
    keep=[X.index[0]]
    for y in X.index[1:]:
        if not np.allclose(X.loc[y].values,X.loc[keep[-1]].values): keep.append(y)
    A=X.loc[keep]; gaps=np.diff(A.index.values)[:,None].astype(float)
    return np.diff(A.values,axis=0)/np.sqrt(gaps)

def pooled(X,seed):
    d=anchor_diffs(X); cov=np.cov(d,rowvar=False); a=0.3 if len(d)>=50 else 0.6; cov=(1-a)*cov+a*np.diag(np.diag(cov))+1e-4*np.eye(32)
    yrs=X.index.values; dt=np.diff(yrs)[:,None].astype(float); rate=np.diff(X.values,axis=0)/dt; drift=rate[yrs[:-1]>=2015].mean(axis=0)
    mean=X.values[yrs>=1980].mean(axis=0) if X.index.min()<1980 else X.values.mean(axis=0)
    y0=int(yrs.max()); P27=[];P28=[]
    for i,sc in enumerate(['PERSIST','DRIFT','REVERT']):
        rng=np.random.default_rng(seed+i)
        for _ in range(NPATH):
            x=X.loc[y0].values.copy(); o={}
            for y in range(y0+1,2029):
                e=rng.multivariate_normal(np.zeros(32),cov)
                x = x+e if sc=='PERSIST' else (x+drift+e if sc=='DRIFT' else x+.5*drift+.15*(mean-x)+e)
                x=np.clip(x,1,10); o[y]=x.copy()
            P27.append(o[2027]); P28.append(o[2028])
    return y0,np.array(P27),np.array(P28)

def feats(M):
    st=[state(x) for x in M]
    return dict(V=np.array([s['V'] for s in st]),Vb=np.array([s['Vbar'] for s in st]),Vm=np.array([s['Vmin'] for s in st]),Bb=np.array([s['Bbar'] for s in st]),reg=np.array([s['regime'] for s in st]),S=M[:,16:24].mean(axis=1))
both=lambda a,b:float(np.mean(a&b)); either=lambda a,b:float(np.mean(a|b))
isin=lambda f,k:np.isin(f['reg'],k)
def topk(f,k,n): return np.array([ix(n) in np.argsort(-r)[:k] for r in f['V']])
def botk(f,k,n): return np.array([ix(n) in np.argsort(r)[:k] for r in f['V']])
def shock(fa,fb,b0): return float(np.mean(((fa['Vb']-b0)<=-2)|((fb['Vb']-fa['Vb'])<=-2)))

def claims_usa(fa,fb,s0):
    gap=lambda f:f['V'][:,1]-(f['V'][:,0]+f['V'][:,2])/2; ok=lambda f:isin(f,['Strained','Stable Adaptive'])
    return {'US-1':1-either(ok(fa),ok(fb)),'US-2':both(topk(fa,2,'Shield'),topk(fb,2,'Shield')),'US-3':both(fa['V'][:,2]<4,fb['V'][:,2]<4),'US-4':float(np.mean(fa['V'][:,0]<4)),
      'US-5':both(fa['Bb']<.2,fb['Bb']<.2),'US-6':both(fa['S']>=6,fb['S']>=6),'US-7':both(gap(fa)>=5,gap(fb)>=5),'US-8':float(np.mean(np.abs(fb['Vb']-s0['Vbar'])<=2)),
      'US-9':1-either((fa['V'][:,0]>=4)&(fa['V'][:,2]>=4),(fb['V'][:,0]>=4)&(fb['V'][:,2]>=4)),'US-10':shock(fa,fb,s0['Vbar']),
      'US-12':both(isin(fa,['Systemic Crisis']),isin(fb,['Systemic Crisis']))}
def claims_china(fa,fb,s0):
    sev=lambda f:isin(f,SEV)
    return {'CN-1':both(~sev(fa),~sev(fb)),'CN-2':both(isin(fa,['Stable Adaptive']),isin(fb,['Stable Adaptive'])),'CN-3':both(fa['Vb']>10,fb['Vb']>10),
      'CN-4':both(botk(fa,3,'Hands'),botk(fb,3,'Hands')),'CN-5':both(botk(fa,3,'Stewards'),botk(fb,3,'Stewards')),'CN-6':both(topk(fa,3,'Archive'),topk(fb,3,'Archive')),
      'CN-7':both(fa['Bb']>.28,fb['Bb']>.28),'CN-8':float(np.mean(np.abs(fb['Vb']-s0['Vbar'])<=2)),'CN-9':either(fa['Vm']<4,fb['Vm']<4),
      'CN-10':both(np.isin(fa['V'].argmax(1),[1,5]),np.isin(fb['V'].argmax(1),[1,5])),'CN-11':shock(fa,fb,s0['Vbar'])}
def claims_aus(fa,fb,s0):
    sev=lambda f:isin(f,SEV)
    return {'AU-1':both(~sev(fa),~sev(fb)),'AU-2':both(fa['Vb']>=7,fb['Vb']>=7.5),'AU-3':float(np.mean(fb['V'][:,5]>=8.08)),'AU-4':both(topk(fa,3,'Archive'),topk(fb,3,'Archive')),
      'AU-5':both(fa['Bb']>.28,fb['Bb']>.28),'AU-6':both(fa['Vm']>=5,fb['Vm']>=5),'AU-7':either(isin(fa,['Stable Adaptive']),isin(fb,['Stable Adaptive'])),
      'AU-8':float(np.mean(np.abs(fb['Vb']-s0['Vbar'])<=2)),'AU-9':shock(fa,fb,s0['Vbar'])}
CL={'USA':claims_usa,'China':claims_china,'Australia':claims_aus}

if __name__=='__main__':
    rows=[];sysr=[];regr=[];noder=[]
    for soc,surfs in SURF.items():
        for name,fn in surfs.items():
            X=load(fn); y0,A,B=pooled(X,SEED); fa,fb=feats(A),feats(B); s0=state(X.loc[y0].values)
            for cid,p in CL[soc](fa,fb,s0).items(): rows.append(dict(Society=soc,Surface=name,Claim=cid,P=round(p,4)))
            for yr,f in ((2027,fa),(2028,fb)):
                sysr.append(dict(Society=soc,Surface=name,Year=yr,BaseYear=y0,Vbar_base=round(s0['Vbar'],2),Vbar_p10=round(np.percentile(f['Vb'],10),2),Vbar_med=round(np.median(f['Vb']),2),Vbar_p90=round(np.percentile(f['Vb'],90),2),Bbar_med=round(np.median(f['Bb']),3),Regime_base=s0['regime']))
                r=pd.Series(f['reg']).value_counts(normalize=True).mul(100).round(1).to_dict(); r.update(Society=soc,Surface=name,Year=yr); regr.append(r)
                for i,n in enumerate(N): noder.append(dict(Society=soc,Surface=name,Year=yr,Node=n,V_base=round(s0['V'][i],2),V_p10=round(np.percentile(f['V'][:,i],10),2),V_med=round(np.median(f['V'][:,i]),2),V_p90=round(np.percentile(f['V'][:,i],90),2)))
            print(soc,name,'done',flush=True)
    pd.DataFrame(rows).to_csv(os.path.join(OUT,'claim_probabilities_by_surface.csv'),index=False)
    pd.DataFrame(sysr).to_csv(os.path.join(OUT,'system_forecast_by_surface.csv'),index=False)
    pd.DataFrame(regr).fillna(0).to_csv(os.path.join(OUT,'regime_distribution_by_surface.csv'),index=False)
    pd.DataFrame(noder).to_csv(os.path.join(OUT,'node_forecast_by_surface.csv'),index=False)
    json.dump(dict(seed=SEED,n_paths_per_scenario=NPATH,python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__),open(os.path.join(OUT,'run_environment.json'),'w'),indent=1)
