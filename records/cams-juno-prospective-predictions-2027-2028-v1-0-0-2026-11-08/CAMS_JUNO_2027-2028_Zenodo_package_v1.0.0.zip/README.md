# CAMS/JUNO v1.2 prospective predictions 2027–2028: United States, China and Australia

Version 1.0.0 · 8 November 2026 · Kari McKern (ComplexityWorkz) · Neural Nations
Archive DOI: 10.5281/zenodo.24046639

This deposit lodges 32 falsifiable, probability-weighted predictions about the scored organisational state of the USA (12 claims), China (11) and Australia (9) in 2027 and 2028, under the JUNO v1.2-Final classifier, **before the outcomes are scored**. It is a thermometer reading projected forward, not a crystal ball, and takes no political position. JUNO v1.2 is not externally validated; scoring this register is part of the prospective test.

It does not replace the frozen 28 August 2026 register (P-01 to P-12) or the 12 July 2026 six-nation memo, which remain in force.

## Read first
- `CAMS_JUNO_Prospective_Register_2027-2028_v1.0.0.pdf` (or `.md`): the full register, method, scoring rules, claims, limitations.
- `predictions-2027-2028.html`: public web page version (uses the neuralnations.org site stylesheet and scripts).

## Files
| Path | Content |
|---|---|
| `results/FINAL_claims_register.csv` | every claim: stated probability, per-dataset probabilities, tier, falsifier |
| `results/claim_probabilities_by_surface.csv` | simulated probability of each claim on each dataset |
| `results/system_forecast_by_surface.csv`, `regime_distribution_by_surface.csv`, `node_forecast_by_surface.csv` | simulation outputs |
| `data/` | the exact input rows (and scorer envelopes) used |
| `code/cams_register_2027_2028.py` | regenerates all probabilities (seed 2026) |
| `code/build_documents.py`, `code/build_web.py` | rebuild the register and web page from `results/` |
| `SHA256SUMS.txt` | checksums of every file |

## Reproduce
```
cd code
python3 cams_register_2027_2028.py     # writes ../results/*.csv  (needs numpy, pandas)
python3 build_documents.py             # rebuilds the register markdown and FINAL_claims_register.csv
python3 build_web.py                   # rebuilds the web page
```
Environment used: see `results/run_environment.json`. Probabilities are Monte Carlo estimates; the fixed seed reproduces them exactly on the same library versions and to within about one point otherwise.

## Verify integrity
```
sha256sum -c SHA256SUMS.txt
```

## Licence
Text and data: CC BY 4.0 (`LICENSE-CONTENT-CC-BY-4.0.txt`). Code: MIT (`LICENSE-CODE-MIT.txt`).

## Cite
McKern, K. (2026). *CAMS/JUNO v1.2 prospective predictions 2027–2028: United States, China and Australia* (Version 1.0.0). Neural Nations / ComplexityWorkz. DOI: 10.5281/zenodo.24046639.
