#!/usr/bin/env python3
"""After reserving a Zenodo DOI (draft record -> 'Reserve DOI'), run:  python3 finalize_with_doi.py 10.5281/zenodo.XXXXXXX
Replaces the placeholder text in the register, web page, README and metadata, rebuilds the PDF (needs pandoc + wkhtmltopdf),
and rewrites SHA256SUMS.txt. Then upload the folder contents and publish."""
import sys, os, re, hashlib, subprocess, shutil
doi=sys.argv[1].strip(); assert re.match(r'^10\.\d{4,9}/\S+$',doi),'expected a DOI like 10.5281/zenodo.1234567'
root=os.path.dirname(os.path.abspath(__file__)); ph='to be inserted after deposit'; link=f'https://doi.org/{doi}'
md='CAMS_JUNO_Prospective_Register_2027-2028_v1.0.0.md'
for f in (md,'predictions-2027-2028.html','README.md'):
    p=os.path.join(root,f); s=open(p,encoding='utf-8').read(); s=s.replace(ph,doi if f!='predictions-2027-2028.html' else f'<a href="{link}">{doi}</a>'); open(p,'w',encoding='utf-8').write(s)
# .zenodo.json is deliberately left unchanged: a Zenodo-reserved DOI is applied by Zenodo itself, so metadata must not carry a 'doi' field.
if shutil.which('pandoc') and shutil.which('wkhtmltopdf'):
    css=os.path.join(root,'code','register_pdf.css'); tmp=os.path.join(root,'_reg.html')
    subprocess.run(['pandoc',os.path.join(root,md),'-f','markdown','-t','html5','--standalone',f'--css={css}','--metadata','pagetitle=CAMS/JUNO v1.2 Prospective Predictions 2027-2028','-o',tmp],check=True)
    subprocess.run(['wkhtmltopdf','--quiet','--enable-local-file-access','--disable-smart-shrinking','-O','Landscape','-s','A4','--margin-top','12','--margin-bottom','12','--margin-left','10','--margin-right','10',tmp,os.path.join(root,md.replace('.md','.pdf'))],check=False); os.remove(tmp)
else: print('pandoc/wkhtmltopdf not found: regenerate the PDF from the .md yourself so it carries the DOI.')
lines=[]
for dp,_,fs in os.walk(root):
    for f in sorted(fs):
        if f in ('SHA256SUMS.txt',) or f.endswith('.pyc') or '__pycache__' in dp: continue
        fp=os.path.join(dp,f); lines.append(f'{hashlib.sha256(open(fp,"rb").read()).hexdigest()}  {os.path.relpath(fp,root)}')
open(os.path.join(root,'SHA256SUMS.txt'),'w').write('\n'.join(sorted(lines,key=lambda l:l.split("  ",1)[1]))+'\n'); print('DOI inserted, checksums rewritten:',doi)
