#!/usr/bin/env python3
"""Check a CAMS archive ZIP against its SHA-256 and its internal content manifest."""
import sys, json, hashlib, zipfile, pathlib

def sha(b):return hashlib.sha256(b).hexdigest()

def main():
    if len(sys.argv) not in (2,3):
        print('Usage: python VERIFY_CONTENTS.py ARCHIVE.zip [EXPECTED_64_HEX_SHA256]')
        return 2
    path=pathlib.Path(sys.argv[1]); actual=sha(path.read_bytes())
    print('ZIP SHA256:',actual)
    if len(sys.argv)==3 and actual.lower()!=sys.argv[2].lower().strip():
        print('FAIL: external SHA-256 mismatch');return 1
    with zipfile.ZipFile(path) as z:
        if z.testzip():raise ValueError('Corrupt ZIP member')
        manifest=json.loads(z.read('MANIFEST_SHA256.json'))
        actualmembers=set(z.namelist())-{'MANIFEST_SHA256.json'}
        expectedmembers=set(manifest['files'])
        if actualmembers!=expectedmembers:
            raise ValueError(f'Member mismatch {actualmembers ^ expectedmembers}')
        for name,spec in manifest['files'].items():
            data=z.read(name)
            if len(data)!=spec['bytes'] or sha(data)!=spec['sha256']:
                raise ValueError('FAIL: content mismatch '+name)
    print('PASS: internal manifest and ZIP archive integrity verified')
    if len(sys.argv)==2:print('WARNING: no external trusted checksum supplied; internal integrity alone is not authenticity.')
    return 0
if __name__=='__main__':sys.exit(main())
