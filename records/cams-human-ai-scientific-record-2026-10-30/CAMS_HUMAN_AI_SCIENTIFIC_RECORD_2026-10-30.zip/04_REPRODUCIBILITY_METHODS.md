# Method and reproducibility note

The attached USA mean dataset covers 1900–2026. For each node, Coherence (C), Capacity (K), Stress (S) and Abstraction (A) have been supplied. The proposed exploratory composite is `Q=A*C+K-S`; it is distinct from the older ensemble `Node Value` formula.

The 25 historical bins include pre-1900 periods for which the provided annual USA ensemble has no observations. Such bins cannot be treated as measured values of that ensemble, but remain legitimate historical context for independent reconstruction.

The blind rater protocol involved 25 cases × eight node roles. Two of the uploaded archives, `files (27).zip` and `files (28).zip`, include the same Claude rating text. The independent Grok CSV was supplied separately and is labelled according to the researcher's statement; there is no independent signed declaration inside that CSV.

Pairwise Q comparisons recalculated from the attached files:

| A | B | Matched complete Q rows | Pearson | Spearman |
|---|---|---:|---:|---:|
| Frozen response | Claude submission | 175 | 0.930788 | 0.932066 |
| Frozen response | Grok submission (user-attributed) | 200 | 0.889473 | 0.888487 |
| Claude submission | Grok submission (user-attributed) | 175 | 0.896246 | 0.898634 |


Three-way absolute agreement ICC(A,1) across 175 complete records: **0.869021**. Calculated as:

`ICC(A,1) = (MS_rows-MS_error)/(MS_rows+(k-1)*MS_error + k*(MS_columns-MS_error)/n)`

This supports reliability of interpretations of **the same casebook**. It does not establish independently collected evidence; that is a distinct research design question. No claim about the validity of CAMS requires AI raters to be infallible, and no blanket rejection of AI ratings follows from their origin.

**No JUNO runtime was available in this archival pass**; numerical figures here are direct operations on supplied C/K/S/A values, and downstream JUNO graph-theoretic calculations remain a separate task.
