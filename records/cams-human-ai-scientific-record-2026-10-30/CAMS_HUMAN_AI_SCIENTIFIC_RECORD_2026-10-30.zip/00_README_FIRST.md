# CAMS scientific record: START HERE

Archive version: 1.0 (2026-10-30)

This package documents a conversation about the development, evaluation and intellectual purpose of CAMS / The Dynamics of Organisations. It preserves a curated research account, selected first-person quotations, an event chronology, the available dataset and blind-rater attachments, and a manifest of the bytewise contents. It does not claim to be the complete message-by-message ChatGPT transcript for an approximately 30-month collaboration.

FILES:
- 01_SUMMARY.md — scientific and historical interpretation
- 02_THREAD_CHRONOLOGY.md — topical reconstruction of the visible conversation
- 03_PRIMARY_EXCERPTS.md — selected user quotations (not a raw transcript)
- 04_METHODS.md — scoring reproducibility, provenance, results
- 05_PROVENANCE_AND_VERIFICATION.md — hash caveats, signing/timestamp strategy
- source_attachments/ — six files as supplied for this session, unmodified
- MANIFEST_SHA256.json — SHA-256 digest of every content file
- VERIFY_CONTENTS.py — portable integrity-verification script

A separate file containing the ZIP SHA-256 and a QR image are distributed alongside the archive. Verify the external checksum BEFORE treating the enclosed material as unchanged.
