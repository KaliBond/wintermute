# Provenance, authenticity and preservation protocol

**This is an archive of curated current-conversation evidence, not a certified export of 30 months of raw ChatGPT history.** The researcher's earlier dialogue with GPT-4 is described in the testimony and chronology, but its original message-level contents are not in this archive.

## What the checksums prove

- Every enclosed item (other than the manifest itself) has a SHA-256 digest recorded in `MANIFEST_SHA256.json`.
- The ZIP has an independently stored `.sha256` file. A QR code records the ZIP file's name and exact SHA-256 digest. Recomputing SHA-256 on the archive and comparing with the QR detects any bit-level change in that ZIP.
- The QR contains textual verification information; it does **not** point to an online hosted verification service. It does not require internet access to scan.

## What they do not prove

- That the text was directly exported from ChatGPT, that either participant authored particular statements, that the dates were notarised, or that this ZIP contains an entire 30-month collaboration.
- A hash is not a digital signature and a self-generated timestamp is not a trusted third-party timestamp.

## Gold-standard next steps

1. Export the complete conversation(s) from ChatGPT using the account's data-export feature; preserve original export files without editing and hash them separately. Do not replace authentic raw exports with curated reconstructions.
2. Attach exported raw message metadata, identifiers and timestamps to a new versioned evidence bundle. Keep editorial summaries clearly separate from verbatim sources.
3. Sign the outer ZIP hash with a **researcher-controlled** Ed25519 or other established public/private key and publish the verifying public key. Neither ChatGPT nor the assistant should claim to sign as the researcher.
4. Anchor the archive hash with an independent time-stamping mechanism (e.g. trusted RFC 3161 timestamp, OpenTimestamps, or stable repository deposit) and publish a DOI/versioned release if appropriate.
5. Preserve the original version permanently. Make amended copies as new versions with separate hashes and a change log.
6. Review selected personal disclosures before making the archive public.

## Manual verification

If the ZIP filename is unchanged, the checksum can be checked using:

- Windows PowerShell: `Get-FileHash -Algorithm SHA256 .\CAMS_HUMAN_AI_SCIENTIFIC_RECORD_2026-10-30.zip`
- macOS/Linux: `shasum -a 256 CAMS_HUMAN_AI_SCIENTIFIC_RECORD_2026-10-30.zip`
- Cross-platform: `python VERIFY_CONTENTS.py <archive.zip> <expected_sha256>`

The 64-digit hexadecimal output must match the value in the `.sha256` file and QR code.
